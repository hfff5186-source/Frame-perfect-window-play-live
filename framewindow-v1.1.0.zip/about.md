# Frame Window

Instant frame window for every wave click, NaN-style. No replay, no waiting: the window is calculated the moment you click.

- **Rings**: an expanding ring at every click, red = 1 frame, green = wide window.
- **Counter** (top left): how many clicks had a 1f, 2f, 3f, 4f, 5f+ window.
- **Circles** on the click offsets (green = safe, red = dies) and **Lines** (white = your click, green = earliest / latest safe click, red = first that dies).
- **Text**: the window in frames, for example `6f [-2 | +3]`.
- **History**: last windows, the tightest one, tight click count.
- **Freeze** keeps the last measurement, **Enabled** turns the mod off.

Press **Window** in the pause menu (top left) for the menu.

Original by yausaf

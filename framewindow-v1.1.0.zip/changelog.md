# v1.1.0

- NaN-style rings at every click (red = 1 frame, green = wide window)
- Window counters (1f / 2f / 3f / 4f / 5f+) in the top left
- Menu: Rings and Counter toggles, 6 rows per column

# v1.0.0

- First release: instant per-click window (wave), circles and trajectory lines, text, history, freeze, Player 1 / Player 2

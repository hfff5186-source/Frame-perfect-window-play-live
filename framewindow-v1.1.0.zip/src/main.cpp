#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/ui/GeodeUI.hpp>
#include <algorithm>
#include <cmath>
#include <functional>
#include <string>
#include <vector>

using namespace geode::prelude;

// ======================================================================
//  GEOMETRY + WINDOW MATH  (pure logic, no game calls)
// ======================================================================
// ---- GEOMETRY BEGIN
struct Obs {
    int kind = 0;             // 0 rect, 1 triangle (slope), 2 circle
    CCRect rect;              // bounding box
    CCPoint tri[3];
    CCPoint center;
    float radius = 0.f;
};

using ObsList = std::vector<Obs const*>;

static float sgn(CCPoint a, CCPoint b, CCPoint c) {
    return (a.x - c.x) * (b.y - c.y) - (b.x - c.x) * (a.y - c.y);
}

static bool inTri(CCPoint p, CCPoint const* t) {
    float d1 = sgn(p, t[0], t[1]);
    float d2 = sgn(p, t[1], t[2]);
    float d3 = sgn(p, t[2], t[0]);
    bool neg = d1 < 0 || d2 < 0 || d3 < 0;
    bool pos = d1 > 0 || d2 > 0 || d3 > 0;
    return !(neg && pos);
}

static bool rectTri(CCRect const& r, CCPoint const* t) {
    float xs[3] = {r.getMinX(), r.getMidX(), r.getMaxX()};
    float ys[3] = {r.getMinY(), r.getMidY(), r.getMaxY()};
    for (float x : xs)
        for (float y : ys)
            if (inTri(CCPoint(x, y), t)) return true;
    for (int i = 0; i < 3; i++) {
        auto a = t[i];
        auto b = t[(i + 1) % 3];
        if (r.containsPoint(a)) return true;
        if (r.containsPoint(CCPoint((a.x + b.x) / 2.f, (a.y + b.y) / 2.f))) return true;
    }
    return false;
}

static bool circleRect(CCPoint c, float rad, CCRect const& r) {
    float cx = std::clamp(c.x, r.getMinX(), r.getMaxX());
    float cy = std::clamp(c.y, r.getMinY(), r.getMaxY());
    float dx = c.x - cx;
    float dy = c.y - cy;
    return dx * dx + dy * dy <= rad * rad;
}

static bool hitsList(ObsList const& list, CCRect const& s) {
    for (auto o : list) {
        if (o->rect.getMaxX() < s.getMinX() || o->rect.getMinX() > s.getMaxX() ||
            o->rect.getMaxY() < s.getMinY() || o->rect.getMinY() > s.getMaxY()) continue;
        if (o->kind == 0) return true;
        if (o->kind == 1 && rectTri(s, o->tri)) return true;
        if (o->kind == 2 && circleRect(o->center, o->radius, s)) return true;
    }
    return false;
}

static void filterObs(std::vector<Obs> const& cache, ObsList& out,
                      float minX, float maxX, float minY, float maxY) {
    out.clear();
    for (auto const& o : cache) {
        if (o.rect.getMaxX() < minX || o.rect.getMinX() > maxX ||
            o.rect.getMaxY() < minY || o.rect.getMinY() > maxY) continue;
        out.push_back(&o);
    }
}

// The wave moves dx forward and +-d up/down every tick.
// A click flips the direction (dOld -> -dOld).
struct WinInput {
    float x0 = 0.f, y0 = 0.f;     // sensor center at the moment of the click
    float dx = 0.f, d = 0.f;      // per tick: forward step and vertical step
    float hsx = 0.f, hsy = 0.f;   // sensor half size (the wave hitbox)
    float dOld = 1.f;             // direction before the click: +1 up, -1 down
    int N = 8;                    // offsets tested on each side
    int Lh = 8;                   // ticks that must stay safe after the click
    int since = 1000;             // ticks since the previous click (limits "earlier")
};

struct WinResult {
    int back = 0;                 // earlier offsets available: -back .. -1
    std::vector<float> f;         // survival fraction per offset, index k + back
    int kmin = 0, kmax = 0;       // safe offsets around the real click
    int window = 0;               // frames: kmax - kmin + 1  (0 = the click itself is unsafe)
};

// The same click shifted by k ticks (k < 0 earlier, k > 0 later).
// Returns the ticks survived; `horizon` is the ticks that had to be survived.
static int simShift(ObsList const& obs, WinInput const& in, int k, int& horizon,
                    std::vector<CCPoint>* path) {
    int surv = 0;
    float dNew = -in.dOld;
    if (k >= 0) {
        horizon = k + in.Lh;
        if (path) path->push_back(CCPoint(in.x0, in.y0));
        for (int i = 1; i <= horizon; i++) {
            float y = (i <= k) ? in.y0 + in.dOld * in.d * static_cast<float>(i)
                               : in.y0 + in.dOld * in.d * static_cast<float>(k) +
                                 dNew * in.d * static_cast<float>(i - k);
            float x = in.x0 + static_cast<float>(i) * in.dx;
            if (path) path->push_back(CCPoint(x, y));
            CCRect s(x - in.hsx, y - in.hsy, 2.f * in.hsx, 2.f * in.hsy);
            if (hitsList(obs, s)) break;
            surv = i;
        }
    } else {
        int m = -k;
        horizon = m + in.Lh;
        float xs = in.x0 - static_cast<float>(m) * in.dx;
        float ys = in.y0 - in.dOld * in.d * static_cast<float>(m);
        if (path) path->push_back(CCPoint(xs, ys));
        for (int j = 1; j <= horizon; j++) {
            float x = xs + static_cast<float>(j) * in.dx;
            float y = ys + dNew * in.d * static_cast<float>(j);
            if (path) path->push_back(CCPoint(x, y));
            CCRect s(x - in.hsx, y - in.hsy, 2.f * in.hsx, 2.f * in.hsy);
            if (hitsList(obs, s)) break;
            surv = j;
        }
    }
    return surv;
}

static WinResult computeWindow(ObsList const& obs, WinInput const& in) {
    WinResult r;
    r.back = std::max(0, std::min(in.N, in.since));
    r.f.assign(static_cast<size_t>(r.back + in.N + 1), 0.f);
    for (int k = -r.back; k <= in.N; k++) {
        int h = 1;
        int s = simShift(obs, in, k, h, nullptr);
        r.f[static_cast<size_t>(k + r.back)] = h > 0 ? static_cast<float>(s) / static_cast<float>(h) : 0.f;
    }
    auto ok = [&](int k) { return r.f[static_cast<size_t>(k + r.back)] >= 0.999f; };
    if (!ok(0)) {
        r.window = 0;
        return r;
    }
    r.kmin = 0;
    while (r.kmin - 1 >= -r.back && ok(r.kmin - 1)) r.kmin--;
    r.kmax = 0;
    while (r.kmax + 1 <= in.N && ok(r.kmax + 1)) r.kmax++;
    r.window = r.kmax - r.kmin + 1;
    return r;
}
// ---- GEOMETRY END

// ======================================================================
//  STATE
// ======================================================================
namespace {
    struct Motion {
        bool haveLast = false;
        float lastX = 0.f, lastY = 0.f;
        float dx = 0.f;   // x movement per tick
        float k = 1.f;    // |dy| / dx of the wave
    };

    Motion s_motion[2];
    bool s_hold[2] = {false, false};      // real button state per input channel
    int s_since[2] = {1000, 1000};        // ticks since the last click per channel
    bool s_twoP = false;
    float s_dt = 1.f / 240.f;

    bool s_active[2] = {false, false};    // a measurement is on screen
    float s_expire[2] = {0.f, 0.f};

    std::vector<Obs> s_cache;
    float s_cacheX = -1e9f;

    // history of the current attempt
    std::vector<int> s_hist;
    int s_minWindow = -1;
    int s_tightCount = 0;

    // window size counters: 0 = the click would die, 1..4 = that many frames, 5 = five or more
    int s_buckets[6] = {0, 0, 0, 0, 0, 0};

    // expanding rings (NaN-style): one per click
    struct Ring {
        CCPoint pos;
        float age = 0.f;
        float life = 0.4f;
        float maxR = 28.f;
        ccColor4F col = {1.f, 1.f, 1.f, 1.f};
    };
    std::vector<Ring> s_rings;

    void resetState() {
        for (int i = 0; i < 2; i++) {
            s_motion[i] = Motion();
            s_hold[i] = false;
            s_since[i] = 1000;
            s_active[i] = false;
            s_expire[i] = 0.f;
        }
        s_twoP = false;
        s_cache.clear();
        s_cacheX = -1e9f;
        s_hist.clear();
        s_minWindow = -1;
        s_tightCount = 0;
        for (int i = 0; i < 6; i++) s_buckets[i] = 0;
        s_rings.clear();
    }

    int chanOf(int pi) { return (s_twoP && pi == 1) ? 1 : 0; }
}

// ======================================================================
//  LEVEL CACHE
// ======================================================================
static void rebuildCache(GJBaseGameLayer* L, float px) {
    s_cache.clear();
    s_cacheX = px;
    if (!L->m_objects) return;

    for (auto obj : CCArrayExt<GameObject*>(L->m_objects)) {
        if (!obj) continue;
        auto type = obj->m_objectType;
        if (type != GameObjectType::Solid && type != GameObjectType::Hazard &&
            type != GameObjectType::Slope) continue;

        float ox = obj->getPositionX();
        if (ox < px - 200.f || ox > px + 700.f) continue;

        Obs o;
        o.rect = obj->getObjectRect();
        if (o.rect.size.width <= 0.f || o.rect.size.height <= 0.f) continue;

        if (type == GameObjectType::Slope) {
            o.kind = 1;
            CCPoint v[3] = {CCPoint(0, 0), CCPoint(1, 0), CCPoint(1, 1)};
            for (auto& p : v) {
                if (obj->m_isFlipX) p.x = 1.f - p.x;
                if (obj->m_isFlipY) p.y = 1.f - p.y;
            }
            int turns = ((static_cast<int>(std::lround(obj->getRotation() / 90.f)) % 4) + 4) % 4;
            for (int t = 0; t < turns; t++) {
                for (auto& p : v) {
                    float dx = p.x - 0.5f;
                    float dy = p.y - 0.5f;
                    p = CCPoint(0.5f + dy, 0.5f - dx);
                }
            }
            for (int i = 0; i < 3; i++) {
                o.tri[i] = CCPoint(
                    o.rect.origin.x + v[i].x * o.rect.size.width,
                    o.rect.origin.y + v[i].y * o.rect.size.height
                );
            }
        } else if (type == GameObjectType::Hazard && obj->m_objectRadius > 0.f) {
            o.kind = 2;
            o.center = obj->getPosition();
            o.radius = obj->m_objectRadius;
            o.rect = CCRect(o.center.x - o.radius, o.center.y - o.radius, o.radius * 2.f, o.radius * 2.f);
        }
        s_cache.push_back(o);
    }
}

static void ensureCache(GJBaseGameLayer* L, float px) {
    if (s_cacheX < -1e8f || px > s_cacheX + 250.f || px < s_cacheX - 5.f) {
        rebuildCache(L, px);
    }
}

static void trackMotion(int pi, PlayerObject* p) {
    auto& m = s_motion[pi];
    float px = p->getPositionX();
    float py = p->getPositionY();
    if (m.haveLast) {
        float dx = px - m.lastX;
        float dy = py - m.lastY;
        if (dx > 0.001f && dx < 100.f) {
            m.dx = dx;
            float k = std::fabs(dy) / dx;
            if (k > 0.3f && k < 3.f) m.k = k;
        } else if (dx < -1.f || dx >= 100.f) {
            m.dx = 0.f;
            m.k = 1.f;
            s_cacheX = -1e9f;
        }
    }
    m.lastX = px;
    m.lastY = py;
    m.haveLast = true;
}

// sensor box = the game's own wave hitbox (red box) + margin
struct Box {
    float hsx, hsy, ox, oy;
};

static Box makeBox(PlayerObject* p, float px, float py) {
    auto mod = Mod::get();
    float base = static_cast<float>(mod->getSettingValue<double>("hitbox-size"));
    float margin = static_cast<float>(mod->getSettingValue<double>("margin"));

    Box b{0.f, 0.f, 0.f, 0.f};
    bool got = false;
    if (mod->getSettingValue<bool>("auto-hitbox")) {
        CCRect r = p->getObjectRect();
        if (r.size.width > 0.5f && r.size.width < 60.f &&
            r.size.height > 0.5f && r.size.height < 60.f) {
            b.hsx = r.size.width / 2.f + margin;
            b.hsy = r.size.height / 2.f + margin;
            b.ox = r.getMidX() - px;
            b.oy = r.getMidY() - py;
            got = true;
        }
    }
    if (!got) {
        b.hsx = b.hsy = (base * p->m_vehicleSize) / 2.f + margin;
    }
    b.hsx = std::max(0.25f, b.hsx);
    b.hsy = std::max(0.25f, b.hsy);
    return b;
}

// ======================================================================
//  DRAWING
// ======================================================================
static std::string drawId(int pi) { return pi == 0 ? "framewindow-draw-1" : "framewindow-draw-2"; }
static std::string textId(int pi) { return pi == 0 ? "framewindow-text-1" : "framewindow-text-2"; }

static void clearDisplay(GJBaseGameLayer* L, int pi) {
    s_active[pi] = false;
    if (!L->m_objectLayer) return;
    if (auto n = L->m_objectLayer->getChildByID(drawId(pi))) n->removeFromParent();
    if (auto n = L->m_objectLayer->getChildByID(textId(pi))) n->removeFromParent();
}

// green (safe) -> yellow -> red (dies)
static ccColor4F gradient(float f, float a) {
    f = std::clamp(f, 0.f, 1.f);
    float r = std::min(1.f, 2.f * (1.f - f));
    float g = std::min(1.f, 2.f * f);
    return ccColor4F{r, g, 0.1f, a};
}

static ccColor3B windowColor(int w, int tight) {
    if (w <= tight) return ccColor3B{255, 70, 70};
    if (w <= tight * 2 + 2) return ccColor3B{255, 200, 60};
    return ccColor3B{90, 255, 120};
}

static void drawPath(CCDrawNode* node, std::vector<CCPoint> const& pts, ccColor4F col, float width) {
    for (size_t i = 1; i < pts.size(); i++) {
        node->drawSegment(pts[i - 1], pts[i], width, col);
    }
}

static void updateHistoryLabel() {
    auto pl = PlayLayer::get();
    if (!pl || !pl->m_uiLayer) return;
    auto lab = typeinfo_cast<CCLabelBMFont*>(pl->m_uiLayer->getChildByID("framewindow-hist"));
    if (!lab) return;
    if (!Mod::get()->getSettingValue<bool>("show-history") || s_hist.empty()) {
        lab->setString("");
        return;
    }
    std::string last;
    size_t from = s_hist.size() > 6 ? s_hist.size() - 6 : 0;
    for (size_t i = from; i < s_hist.size(); i++) {
        last += fmt::format("{} ", s_hist[i]);
    }
    lab->setString(fmt::format("last: {}| min {}f | tight {}", last, s_minWindow, s_tightCount).c_str());
}

static void updateCounterLabel() {
    auto pl = PlayLayer::get();
    if (!pl || !pl->m_uiLayer) return;
    auto lab = typeinfo_cast<CCLabelBMFont*>(pl->m_uiLayer->getChildByID("framewindow-count"));
    if (!lab) return;
    int total = 0;
    for (int i = 0; i < 6; i++) total += s_buckets[i];
    if (!Mod::get()->getSettingValue<bool>("show-counter") || total == 0) {
        lab->setString("");
        return;
    }
    lab->setString(fmt::format("1f:{} 2f:{} 3f:{} 4f:{} 5f+:{}",
        s_buckets[1], s_buckets[2], s_buckets[3], s_buckets[4], s_buckets[5]).c_str());
}

// expanding, fading rings at every click, colored by the window size
static void updateRings(GJBaseGameLayer* L, float dt) {
    if (!L->m_objectLayer) return;
    auto node = static_cast<CCDrawNode*>(L->m_objectLayer->getChildByID("framewindow-rings"));
    if (s_rings.empty()) {
        if (node) node->clear();
        return;
    }
    if (!node) {
        node = CCDrawNode::create();
        node->setID("framewindow-rings");
        L->m_objectLayer->addChild(node, 999);
    }
    node->clear();

    for (auto& r : s_rings) r.age += dt;
    s_rings.erase(std::remove_if(s_rings.begin(), s_rings.end(),
                                 [](Ring const& r) { return r.age >= r.life; }),
                  s_rings.end());

    constexpr int SEG = 22;
    constexpr float PI2 = 6.2831853f;
    for (auto const& r : s_rings) {
        float u = r.age / r.life;
        float e = 1.f - (1.f - u) * (1.f - u);       // fast start, slow end
        float rad = 4.f + (r.maxR - 4.f) * e;
        ccColor4F c = r.col;
        c.a = 1.f - u;
        for (int i = 0; i < SEG; i++) {
            float a0 = PI2 * static_cast<float>(i) / SEG;
            float a1 = PI2 * static_cast<float>(i + 1) / SEG;
            node->drawSegment(
                CCPoint(r.pos.x + rad * std::cos(a0), r.pos.y + rad * std::sin(a0)),
                CCPoint(r.pos.x + rad * std::cos(a1), r.pos.y + rad * std::sin(a1)),
                1.0f, c
            );
        }
    }
}

// ======================================================================
//  MEASURE ONE CLICK  (instant: pure math, nothing is replayed)
// ======================================================================
static void measure(GJBaseGameLayer* L, int pi, PlayerObject* p, bool oldHold) {
    auto mod = Mod::get();
    auto& m = s_motion[pi];
    if (m.dx <= 0.01f) return;

    float px = p->getPositionX();
    float py = p->getPositionY();
    Box bx = makeBox(p, px, py);

    float sign = p->m_isUpsideDown ? -1.f : 1.f;
    bool oldUp = oldHold ? (sign > 0.f) : (sign < 0.f);

    WinInput in;
    in.x0 = px + bx.ox;
    in.y0 = py + bx.oy;
    in.dx = m.dx;
    in.d = m.k * m.dx;
    in.hsx = bx.hsx;
    in.hsy = bx.hsy;
    in.dOld = oldUp ? 1.f : -1.f;
    in.N = std::clamp(static_cast<int>(mod->getSettingValue<int64_t>("range")), 1, 30);
    float look = static_cast<float>(mod->getSettingValue<double>("lookahead"));
    in.Lh = std::clamp(static_cast<int>(std::ceil(look / std::max(s_dt, 0.0005f))), 2, 90);
    in.since = s_since[chanOf(pi)];

    ensureCache(L, in.x0);

    int back = std::max(0, std::min(in.N, in.since));
    float reachX = static_cast<float>(in.N + in.Lh) * in.dx;
    float reachY = static_cast<float>(back + in.N + in.Lh) * in.d;
    ObsList obs;
    filterObs(s_cache, obs,
              in.x0 - static_cast<float>(back) * in.dx - in.hsx - 2.f, in.x0 + reachX + in.hsx + 2.f,
              in.y0 - reachY - in.hsy - 2.f, in.y0 + reachY + in.hsy + 2.f);

    WinResult res = computeWindow(obs, in);
    int tight = static_cast<int>(mod->getSettingValue<int64_t>("tight"));

    // ---- history
    s_hist.push_back(res.window);
    if (s_minWindow < 0 || res.window < s_minWindow) s_minWindow = res.window;
    if (res.window <= tight) s_tightCount++;
    updateHistoryLabel();

    // counters
    s_buckets[std::clamp(res.window, 0, 5)]++;
    updateCounterLabel();

    // NaN-style ring: red = 1 frame ... green = wide window
    if (mod->getSettingValue<bool>("show-rings")) {
        int greenAt = std::clamp(static_cast<int>(mod->getSettingValue<int64_t>("green-at")), 2, 30);
        float t = res.window <= 0 ? 0.f
                : std::clamp(static_cast<float>(res.window - 1) / static_cast<float>(greenAt - 1), 0.f, 1.f);
        Ring r;
        r.pos = CCPoint(in.x0, in.y0);
        r.life = std::max(0.1f, static_cast<float>(mod->getSettingValue<double>("ring-time")));
        r.maxR = static_cast<float>(mod->getSettingValue<double>("ring-size"));
        r.col = res.window <= 0 ? ccColor4F{0.75f, 0.f, 0.3f, 1.f} : gradient(t, 1.f);
        s_rings.push_back(r);
        if (s_rings.size() > 24) s_rings.erase(s_rings.begin());
    }

    if (!L->m_objectLayer) return;

    // ---- drawing
    auto node = static_cast<CCDrawNode*>(L->m_objectLayer->getChildByID(drawId(pi)));
    if (!node) {
        node = CCDrawNode::create();
        node->setID(drawId(pi));
        L->m_objectLayer->addChild(node, 1000);
    }
    node->clear();

    if (mod->getSettingValue<bool>("show-lines")) {
        std::vector<CCPoint> pts;
        auto line = [&](int k, ccColor4F col, float w) {
            if (k < -res.back || k > in.N) return;
            pts.clear();
            int h = 1;
            simShift(obs, in, k, h, &pts);
            drawPath(node, pts, col, w);
        };
        if (res.window > 0) {
            line(res.kmin, ccColor4F{0.2f, 1.f, 0.3f, 0.9f}, 0.5f);   // earliest safe click
            line(res.kmax, ccColor4F{0.2f, 1.f, 0.3f, 0.9f}, 0.5f);   // latest safe click
            line(res.kmin - 1, ccColor4F{1.f, 0.2f, 0.2f, 0.9f}, 0.5f); // first that dies (earlier)
            line(res.kmax + 1, ccColor4F{1.f, 0.2f, 0.2f, 0.9f}, 0.5f); // first that dies (later)
        }
        line(0, ccColor4F{1.f, 1.f, 1.f, 1.f}, 0.8f);                 // your click
    }

    if (mod->getSettingValue<bool>("show-circles")) {
        for (int k = -res.back; k <= in.N; k++) {
            float f = res.f[static_cast<size_t>(k + res.back)];
            CCPoint pos = k >= 0
                ? CCPoint(in.x0 + static_cast<float>(k) * in.dx, in.y0 + in.dOld * in.d * static_cast<float>(k))
                : CCPoint(in.x0 + static_cast<float>(k) * in.dx, in.y0 + in.dOld * in.d * static_cast<float>(k));
            node->drawDot(pos, k == 0 ? 3.6f : 2.2f, gradient(f, 0.95f));
            if (k == 0) node->drawDot(pos, 1.5f, ccColor4F{1.f, 1.f, 1.f, 1.f});
        }
    }

    // ---- text
    auto old = L->m_objectLayer->getChildByID(textId(pi));
    if (old) old->removeFromParent();
    if (mod->getSettingValue<bool>("show-text")) {
        std::string txt;
        if (res.window == 0) {
            txt = "0f  (dies)";
        } else {
            bool edge = (res.kmin == -in.N) || (res.kmax == in.N);
            txt = fmt::format("{}f{}  [{} | +{}]", res.window, edge ? "+" : "", -res.kmin, res.kmax);
        }
        auto lab = CCLabelBMFont::create(txt.c_str(), "bigFont.fnt");
        lab->setID(textId(pi));
        lab->setScale(0.28f);
        lab->setColor(windowColor(res.window, tight));
        lab->setPosition({in.x0 + 18.f, in.y0 + (in.dOld > 0.f ? -22.f : 22.f)});
        L->m_objectLayer->addChild(lab, 1001);
    }

    s_active[pi] = true;
    float showTime = static_cast<float>(mod->getSettingValue<double>("show-time"));
    bool freeze = mod->getSettingValue<bool>("freeze");
    s_expire[pi] = (freeze || showTime <= 0.f) ? 0.f : showTime;
}

static void onClick(GJBaseGameLayer* L, int ch, bool oldHold) {
    auto mod = Mod::get();
    if (!mod->getSettingValue<bool>("enabled")) return;

    bool useP[2] = {mod->getSettingValue<bool>("player1"), mod->getSettingValue<bool>("player2")};
    PlayerObject* pl[2] = {L->m_player1, L->m_player2};

    for (int pi = 0; pi < 2; pi++) {
        auto p = pl[pi];
        if (!p || p->m_isDead || !p->m_isDart || !useP[pi]) continue;
        if (pi == 1 && !p->isVisible()) continue;
        if (chanOf(pi) != ch) continue;
        measure(L, pi, p, oldHold);
    }
}

static void tick(GJBaseGameLayer* L, float dt) {
    auto p1 = L->m_player1;
    auto p2 = L->m_player2;
    if (!p1) return;

    s_dt = dt;
    s_twoP = L->m_levelSettings && L->m_levelSettings->m_twoPlayerMode;

    if (!p1->m_isDead) trackMotion(0, p1);
    if (p2) trackMotion(1, p2);
    for (int c = 0; c < 2; c++) {
        if (s_since[c] < 100000) s_since[c]++;
    }

    bool enabled = Mod::get()->getSettingValue<bool>("enabled");
    if (!enabled) s_rings.clear();
    updateRings(L, dt);
    for (int pi = 0; pi < 2; pi++) {
        if (!s_active[pi]) continue;
        if (!enabled) {
            clearDisplay(L, pi);
            continue;
        }
        if (s_expire[pi] > 0.f) {
            s_expire[pi] -= dt;
            if (s_expire[pi] <= 0.f) clearDisplay(L, pi);
        }
    }
}

// ======================================================================
//  HOOKS
// ======================================================================
class $modify(FrameWindowGameLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        GJBaseGameLayer::handleButton(down, button, isPlayer1);

        if (button == 1) {
            int c = (s_twoP && !isPlayer1) ? 1 : 0;
            bool before = s_hold[c];
            s_hold[c] = down;
            if (down != before) {
                onClick(this, c, before);   // measured right now, on the click
                s_since[c] = 0;
            }
        }
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        if (!isHalfTick) tick(this, dt);
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
    }
};

class $modify(FrameWindowPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        resetState();

        // small history label in the corner
        auto win = CCDirector::get()->getWinSize();
        auto lab = CCLabelBMFont::create("", "bigFont.fnt");
        lab->setID("framewindow-hist");
        lab->setScale(0.32f);
        lab->setOpacity(190);
        lab->setAnchorPoint({1.f, 1.f});
        lab->setPosition({win.width - 8.f, win.height - 8.f});
        m_uiLayer->addChild(lab, 50);

        // window counters, top left
        auto cnt = CCLabelBMFont::create("", "bigFont.fnt");
        cnt->setID("framewindow-count");
        cnt->setScale(0.3f);
        cnt->setOpacity(190);
        cnt->setAnchorPoint({0.f, 1.f});
        cnt->setPosition({8.f, win.height - 8.f});
        m_uiLayer->addChild(cnt, 50);
        return true;
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        s_hist.clear();
        s_minWindow = -1;
        s_tightCount = 0;
        for (int i = 0; i < 6; i++) s_buckets[i] = 0;
        s_rings.clear();
        updateHistoryLabel();
        updateCounterLabel();
        clearDisplay(this, 0);
        clearDisplay(this, 1);
    }
};

// ======================================================================
//  PAUSE MENU
// ======================================================================
// while the menu is open, the pause screen's own menus ignore touches
static void setPauseMenusEnabled(CCNode* pause, bool enabled) {
    auto kids = pause->getChildren();
    if (!kids) return;
    for (auto child : CCArrayExt<CCNode*>(kids)) {
        if (auto m = typeinfo_cast<CCMenu*>(child)) m->setEnabled(enabled);
    }
}

class $modify(FrameWindowPause, PauseLayer) {
    void openPanel() {
        if (auto old = this->getChildByID("framewindow-panel")) {
            setPauseMenusEnabled(this, true);
            old->removeFromParent();
            return;
        }

        setPauseMenusEnabled(this, false);

        auto win = CCDirector::get()->getWinSize();
        float cx = win.width / 2.f;
        float cy = win.height / 2.f;

        auto panel = CCLayer::create();
        panel->setID("framewindow-panel");

        auto bg = CCScale9Sprite::create("GJ_square01.png");
        bg->setContentSize({400.f, 230.f});
        bg->setPosition({cx, cy});
        panel->addChild(bg);

        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        panel->addChild(menu);

        auto addLabel = [&](char const* text, float x, float y, float scale, bool left) {
            auto l = CCLabelBMFont::create(text, "bigFont.fnt");
            l->setScale(scale);
            if (left) l->setAnchorPoint({0.f, 0.5f});
            l->setPosition({x, y});
            panel->addChild(l);
            return l;
        };

        addLabel("Frame Window", cx, cy + 98.f, 0.6f, false);

        float rowY[6] = {cy + 66.f, cy + 41.f, cy + 16.f, cy - 9.f, cy - 34.f, cy - 59.f};

        // ON/OFF row with a check mark that shows while it is ON
        auto addToggle = [&](char const* key, char const* name, float labelX, float toggleX, float y,
                             std::function<void(bool)> onChange = nullptr) {
            addLabel(name, labelX, y, 0.45f, true);

            auto offSpr = ButtonSprite::create("OFF");
            auto onSpr = ButtonSprite::create("ON");
            offSpr->setScale(0.5f);
            onSpr->setScale(0.5f);

            bool cur = Mod::get()->getSettingValue<bool>(key);
            CCSprite* tick = CCSprite::createWithSpriteFrameName("GJ_checkOn_001.png");
            if (tick) {
                tick->setScale(0.55f);
                tick->setPosition({toggleX - 34.f, y});
                tick->setVisible(cur);
                panel->addChild(tick);
            }

            auto t = CCMenuItemExt::createToggler(onSpr, offSpr, [key, tick, onChange](CCMenuItemToggler* tg) {
                bool nowOn = !tg->isToggled();
                Mod::get()->setSettingValue<bool>(key, nowOn);
                if (tick) tick->setVisible(nowOn);
                if (onChange) onChange(nowOn);
            });
            t->toggle(cur);
            t->setPosition({toggleX, y});
            menu->addChild(t);
        };

        // +/- row (isInt: an int setting)
        auto addStepper = [&](char const* key, char const* name, float labelX, float valX, float y,
                              double step, double lo, double hi, int dec, bool isInt) {
            addLabel(name, labelX, y, 0.45f, true);

            auto readValue = [key, isInt]() -> double {
                return isInt ? static_cast<double>(Mod::get()->getSettingValue<int64_t>(key))
                             : Mod::get()->getSettingValue<double>(key);
            };

            auto val = addLabel(fmt::format("{:.{}f}", readValue(), dec).c_str(), valX, y, 0.45f, false);

            auto change = [val, key, lo, hi, dec, isInt, readValue](double delta) {
                double v = std::clamp(readValue() + delta, lo, hi);
                double p10 = std::pow(10.0, dec);
                v = std::round(v * p10) / p10;
                if (isInt) Mod::get()->setSettingValue<int64_t>(key, static_cast<int64_t>(std::lround(v)));
                else Mod::get()->setSettingValue<double>(key, v);
                val->setString(fmt::format("{:.{}f}", v, dec).c_str());
            };

            auto minusSpr = ButtonSprite::create("-");
            minusSpr->setScale(0.5f);
            auto minus = CCMenuItemExt::createSpriteExtra(minusSpr, [change, step](auto) { change(-step); });
            minus->setPosition({valX - 30.f, y});
            menu->addChild(minus);

            auto plusSpr = ButtonSprite::create("+");
            plusSpr->setScale(0.5f);
            auto plus = CCMenuItemExt::createSpriteExtra(plusSpr, [change, step](auto) { change(step); });
            plus->setPosition({valX + 30.f, y});
            menu->addChild(plus);
        };

        // left column
        float lx = cx - 188.f;
        float lt = cx - 32.f;
        addToggle("enabled", "Enabled", lx, lt, rowY[0], [this](bool on) {
            if (auto tick = this->getChildByIDRecursive("framewindow-check")) tick->setVisible(on);
        });
        addToggle("freeze", "Freeze", lx, lt, rowY[1]);
        addToggle("player1", "Player 1", lx, lt, rowY[2]);
        addToggle("player2", "Player 2", lx, lt, rowY[3]);
        addToggle("show-circles", "Circles", lx, lt, rowY[4]);
        addToggle("show-lines", "Lines", lx, lt, rowY[5]);

        // right column
        float rx = cx + 12.f;
        float rv = cx + 138.f;
        addToggle("show-rings", "Rings", rx, rv, rowY[0]);
        addToggle("show-text", "Text", rx, rv, rowY[1]);
        addToggle("show-counter", "Counter", rx, rv, rowY[2]);
        addToggle("show-history", "History", rx, rv, rowY[3]);
        addStepper("range", "Range", rx, rv, rowY[4], 1.0, 1.0, 30.0, 0, true);
        addStepper("lookahead", "Look Ahead", rx, rv, rowY[5], 0.01, 0.01, 0.4, 2, false);

        // close
        auto closeSpr = ButtonSprite::create("Close");
        closeSpr->setScale(0.5f);
        auto closeBtn = CCMenuItemExt::createSpriteExtra(closeSpr, [this, panel](auto) {
            setPauseMenusEnabled(this, true);
            panel->removeFromParent();
        });
        closeBtn->setPosition({cx, cy - 92.f});
        menu->addChild(closeBtn);

        this->addChild(panel, 2000);
    }

    void customSetup() {
        PauseLayer::customSetup();

        auto winSize = CCDirector::get()->getWinSize();
        bool on = Mod::get()->getSettingValue<bool>("enabled");

        // button 1: the Geode settings list
        auto setSpr = ButtonSprite::create("Settings");
        setSpr->setScale(0.4f);
        auto setBtn = CCMenuItemExt::createSpriteExtra(setSpr, [](auto) {
            openSettingsPopup(Mod::get(), false);
        });
        setBtn->setPosition({28.f, 0.f});

        // button 2: the menu, with a check mark while the mod is enabled
        auto winSpr = ButtonSprite::create("Window");
        winSpr->setScale(0.4f);
        if (auto tick = CCSprite::createWithSpriteFrameName("GJ_checkOn_001.png")) {
            auto sz = winSpr->getContentSize();
            tick->setScale(1.1f);
            tick->setPosition({sz.width - 4.f, sz.height - 2.f});
            tick->setID("framewindow-check");
            tick->setVisible(on);
            winSpr->addChild(tick, 5);
        }
        auto winBtn = CCMenuItemExt::createSpriteExtra(winSpr, [this](auto) {
            this->openPanel();
        });
        winBtn->setPosition({-30.f, 0.f});

        auto menu = CCMenu::create();
        menu->addChild(setBtn);
        menu->addChild(winBtn);
        // the red circle: top left, above the other mods' buttons
        menu->setPosition({126.f, winSize.height - 40.f});
        this->addChild(menu, 1000);
    }
};
